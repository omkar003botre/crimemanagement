from flask import Flask,render_template,url_for,request,redirect
from flask_mysqldb import MySQL

app=Flask(__name__)
app.config['MYSQL_HOST']='bdrapgwbl9xvbym30my3-mysql.services.clever-cloud.com'
app.config['MYSQL_USER']='ukwze17lyqsfpc7t'
app.config['MYSQL_PASSWORD']='m1GjmChYex6KsscHQTom'
app.config['MYSQL_DB']='bdrapgwbl9xvbym30my3'

mysql=MySQL(app)

@app.route("/home")
def home():
    return render_template("index.html")

@app.route("/adminlogin" ,methods=["GET","POST"])
def adminlogin():
    logincur=mysql.connection.cursor()
    if request.method=='POST':
       uname=request.form['loginusername'];
       password=request.form['loginpsw'];
       logincur.execute('SELECT adminid , adminpassword FROM Adminlogin WHERE adminid = %s AND adminpassword= %s', (uname,password,))
       result=logincur.fetchall()
       if result:
           logincur.execute('SELECT adminid ,adminname, phonenumber , emaiid FROM Adminlogin WHERE adminid = %s AND adminpassword= %s', (uname,password,))
           re=logincur.fetchall()
           return render_template("display.html",data=re);
       else:
           return render_template('usernotfound.html',uname=uname);

@app.route("/showadminform")
def showadminform():
    return render_template('newadmin.html')
    
    

@app.route("/newadmin",methods=["GET","POST"])
def newadmin():
    newadmincur=mysql.connection.cursor()
    if request.method=='POST':
        uname=request.form['uname'];
        newadmincur.execute('SELECT * FROM Adminlogin WHERE adminid = %s', (uname,))
        getusername=newadmincur.fetchall()
        if getusername:
            return render_template("allreadyexit.html")
        else:
            upass=request.form['upass'];
            Name=request.form['Name'];
            address=request.form['address'];    
            phno=request.form['phno'];
            eid=request.form['eid'];
            loc=request.form['loc'];
            newadmincur.execute("INSERT INTO Adminlogin(adminid,adminpassword,adminname,Address,phonenumber,emaiid,Location) VALUES(%s,%s,%s,%s,%s,%s,%s) ",(uname,upass,Name,address,phno,eid,loc,))
            mysql.connection.commit()
            return render_template('index.html')
        


           

@app.route("/user",methods=["GET","POST"])
def userlogin():
    Ulogincur=mysql.connection.cursor()
    if request.method=='POST':
       username= request.form['uid'];
       passcode= request.form['upass'];
       Ulogincur.execute('SELECT * FROM userlogin WHERE userid = %s AND userpassword= %s', (username,passcode,))
       result4=Ulogincur.fetchall()
       if result4:
           Ulogincur.execute('SELECT fir_id , fir_name,action,startdate FROM enquiry WHERE action="notfound" ');
           result=Ulogincur.fetchall();
           return render_template("userprofile.html",uid=username,result=result)
       else:
           return render_template('usernotfound.html')

        

@app.route('/managecase')
def managecase():
    mcur=mysql.connection.cursor()
    mcur.execute("SELECT * FROM fir")
    mdata=mcur.fetchall()
    return render_template('managecase.html',mdata=mdata)

@app.route('/deletfir',methods=["GET","POST"])
def deletfir():
    dcur=mysql.connection.cursor()
    if request.method=='POST':
        firid=request.form['firid'];
        firname=request.form['firname'];
        dcur.execute("SELECT firno, typeofcrime FROM fir WHERE firno=%s AND typeofcrime=%s",(firid,firname,))
        result=dcur.fetchall()
        if result:
           dcur.execute("DELETE FROM fir WHERE firno=%s AND typeofcrime=%s",(firid,firname))
           mysql.connection.commit();
           return "<h1>FIR Closed sucessfully</h1>"
        else:
           return "<h1>Invalid  FIR_name  or  FIR_ID</h1>"
            
@app.route("/adduserpage",methods=["GET","POST"])
def adduserpage():
    cur2=mysql.connection.cursor()
    cur2.execute('SELECT userid,name,phonenumber, emaiid , Location FROM userlogin ')
    detail=cur2.fetchall()
    return render_template('addnewuser.html',detail=detail)

@app.route("/adduser",methods=["GET","POST"])
def adduser():
    usercur=mysql.connection.cursor()
    if request.method=='POST':
        uname=request.form['uname'];
        usercur.execute('SELECT * FROM userlogin WHERE userid = %s', (uname,))
        getusername=usercur.fetchall()
        if getusername:
            return render_template("allreadyexit.html")
        else:
            upass=request.form['upass'];
            Name=request.form['Name'];
            address=request.form['address'];    
            phno=request.form['phno'];
            eid=request.form['eid'];
            loc=request.form['loc'];
            usercur.execute("INSERT INTO userlogin(userid,userpassword,name,Address,phonenumber,emaiid,Location) VALUES(%s,%s,%s,%s,%s,%s,%s) ",(uname,upass,Name,address,phno,eid,loc,))
            mysql.connection.commit()
            return render_template('index.html')        
       
    
    

@app.route("/singnout")
def singnout():
    return render_template("singnout.html");


@app.route('/showfirform')
def showfirform():
    return render_template("addnewfir.html");
        
@app.route('/addfirdata',methods=["GET","Post"])
def addfirdata():
    fircur=mysql.connection.cursor()
    if request.method=='POST':
        firno=request.form['firno'];
        District=request.form['District'];
        Date=request.form['Date'];
        odate= request.form['odate'];
        otime=request.form['otime'];
        rdate=request.form['rdate'];
        rtime=request.form['rtime'];
        psaddress=request.form['psAdddress'];
        name=request.form['name'];
        phno=request.form['phno']
        address=request.form['cAdddress']
        toc=request.form['crimetype'];
        fircur.execute("INSERT INTO fir(firno,dis,date,odate,otime,psdate,pstime,policeaddress,cname,cphno,caddress,typeofcrime) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",(firno,District,Date,odate,otime,rdate,rtime,psaddress,name,phno,address,toc,));
        Action="notfound";        
        fircur.execute("INSERT INTO enquiry(fir_id,fir_name,action,founddate,startdate) VALUES(%s,%s,%s,%s,%s)",(firno,toc,Action,rdate,rdate,))
        mysql.connection.commit()
        return "<h2>Fir Added.. </h2>"
    else:
        return "<h2>Failed</h2>"

@app.route("/caseenquiry",methods=["GET","Post"])
def caseenquiry():
    casecur=mysql.connection.cursor();
    if request.method=='POST':
       criminalname=request.form['criminalname'];
       criminalage=request.form['criminalage'];
       gender=request.form['gender'];
       adate=request.form['adate'];
       casename=request.form['casename'];
       fid=request.form['caseid'];
       casecur.execute('SELECT * FROM enquiry WHERE fir_id=%s AND fir_name=%s ',(fid,casename,))
       detail=casecur.fetchall()
       if detail:
           casecur.execute("INSERT INTO criminalsdetail(name,age,gender,Adate,casename) VALUES(%s,%s,%s,%s,%s)",(criminalname,criminalage,gender,adate,casename))
           mysql.connection.commit();
           ACT='found'
           casecur.execute("UPDATE enquiry SET founddate=%s , action=%s WHERE fir_id=%s",(adate,ACT,fid,))
           mysql.connection.commit();
           return render_template('userprofile.html')
       else:
           return "<h1>Case Doesnot Exist  <br>Please enter valid Case Name and case-id</h1>"
    

@app.route('/showcase')
def showcase():
    return render_template('caseenquiry.html')


@app.route('/criminaldetail')
def criminaldetail():
    criminalcur=mysql.connection.cursor();
    criminalcur.execute("SELECT * FROM criminalsdetail");
    data5=criminalcur.fetchall();
    return render_template('criminaldetail.html',data5=data5)

@app.route('/showfir')
def showfir():
    fcur=mysql.connection.cursor();
    fcur.execute("SELECT * FROM fir")
    info=fcur.fetchall();
    return render_template('firdetail.html',info=info)

@app.route('/analysis')
def analysis():
    gcur=mysql.connection.cursor();
    gcur.execute("SELECT dis ,  COUNT(dis) from fir GROUP BY dis ORDER BY dis DESC ");
    most=gcur.fetchall()
    gcur.execute("SELECT typeofcrime ,  COUNT(typeofcrime) from fir GROUP BY typeofcrime ORDER BY typeofcrime DESC ");
    mosttoc=gcur.fetchall()
    gcur.execute("SELECT otime ,  COUNT(otime) from fir GROUP BY otime ORDER BY otime DESC ");
    mosttime=gcur.fetchall()
    gcur.execute("SELECT name ,  COUNT(casename) from criminalsdetail GROUP BY name ORDER BY casename DESC ")
    mostcriminal=gcur.fetchall()
    gcur.execute("SELECT fir_id ,fir_name ,action from enquiry  WHERE action='notfound' ")
    notfound=gcur.fetchall()
    gcur.execute("SELECT caddress,COUNT(caddress) from fir GROUP BY caddress ORDER BY caddress");
    address=gcur.fetchall()
    
    return render_template('graph.html',dist=most,mosttoc=mosttoc,mosttime=mosttime,mostc=mostcriminal,notfound=notfound,address=address)


@app.route('/unitdtail')
def unitdetail():
    curt=mysql.connection.cursor();
    curt.execute("SELECT adminname,phonenumber from Adminlogin")
    da=curt.fetchall()
    curt.execute("SELECT name,phonenumber from userlogin")
    udetail=curt.fetchall()
    return render_template('unit.html',da=da,udetail=udetail)
    


@app.route('/forgotform')
def forgotform():
    return render_template('forgotform.html')

@app.route('/getforgotdata',methods=["POST","GET"])
def getforgotdata():
    getcur=mysql.connection.cursor();
    if request.method=='POST':
       adminid=request.form['adminid'];
       phno=request.form['adminmobile']; 
       adminmail=request.form['adminmail'];
       newpas=request.form['newpassc'];
       getcur.execute("SELECT  adminid,phonenumber,emaiid FROM Adminlogin WHERE adminid=%s AND phonenumber=%s AND emaiid=%s",(adminid,phno,adminmail,))
       fetchre=getcur.fetchall()
       if fetchre:
           getcur.execute("UPDATE Adminlogin SET adminpassword=%s WHERE adminid=%s",(newpas,adminid,))
           mysql.connection.commit()
           return redirect('home')
       else:
           return "<h1>Invalid Information</h1>"


@app.route('/showfortform')
def showfortform():
    return render_template('forgotuser.html')
     
@app.route('/forgotuser',methods=["POST","GET"])
def forgotuser():
    fucur=mysql.connection.cursor();
    if request.method=='POST':
        uid=request.form['uid']
        umail=request.form['umail']
        umobile=request.form['umobile']
        newupassc=request.form['newupassc']
        fucur.execute("SELECT userid,emaiid,phonenumber FROM userlogin WHERE userid=%s AND emaiid=%s AND phonenumber=%s",(uid,umail,umobile,))
        getre=fucur.fetchall();
        if getre:
            fucur.execute('UPDATE userlogin SET userpassword=%s WHERE userid=%s',(newupassc,uid))
            mysql.connection.commit()
            return redirect('home')
        else:
            return "<h1>Invalid Information</h1>"

if __name__=="__main__":
    app.run(debug=True)
    

